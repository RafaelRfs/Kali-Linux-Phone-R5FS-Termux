<!DOCTYPE html>
<head>
<meta charset="utf-8" />
<title>Login Teste</title>
</head>
<body>

<?php
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$senha = isset($_POST['senha'])? trim($_POST['senha']) :  '';
$tp = 'post';

if( $nome <> '' && $senha <> ''){
	include('db.php');
	$db =  new Db();
        $sql = 'nome="'.$nome.'"';
	$dt = $db->Read("nome = '".$nome."' and senha = '".$senha."'");
	if(count($dt) == 1){
		echo "<h1>Logged</h1>";
	}
	else{
		echo "<h2>Fail</h2>";
		}	
} 
 
else{ ?>


<form action="" method="<?php echo $tp;?>" enctype="application/x-www-form-urlencoded">
<p>Login: <input type="text" name="nome" /></p>
<p>Senha: <input type="text" name="senha" /></p>
<input type="submit" value="Logar" />
</form>
    
 <?php }	?>

</body>
</html>

